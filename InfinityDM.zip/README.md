# InfinityDM

Dodaj tokeny do tokens.txt
To mają być tokeny BOTÓW
żeby spamić ktoś musi być w tym samym serwerze co boty

# https://discord.gg/infinityservices
